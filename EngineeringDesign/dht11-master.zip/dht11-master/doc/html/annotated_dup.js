var annotated_dup =
[
    [ "dht11_handle_s", "structdht11__handle__s.html", "structdht11__handle__s" ],
    [ "dht11_info_s", "structdht11__info__s.html", "structdht11__info__s" ]
];