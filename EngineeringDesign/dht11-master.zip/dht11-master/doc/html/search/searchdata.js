var indexSectionsWithContent =
{
  0: "bcdeilmst",
  1: "d",
  2: "dm",
  3: "d",
  4: "bcdeimst",
  5: "d",
  6: "cdmst",
  7: "d",
  8: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Modules",
  8: "Pages"
};

